package mainPackage;

import carrera.Carrera;

public class Main {
	public static void main(String[] args) {
		try {
			Carrera carrera = new Carrera(4);
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
}
